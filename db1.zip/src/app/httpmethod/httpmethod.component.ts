import { HttpMethodsService } from './../http-methods.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-httpmethod',
  templateUrl: './httpmethod.component.html',
  styleUrls: ['./httpmethod.component.css'],
})
export class HttpmethodComponent implements OnInit {
  alluser: any;
  isedit=false;
  alert=false;
  edituser = {
    name: '',
    mobileno: '',
    email: '',
    password: '',
    id:'',

  };

  constructor(private service: HttpMethodsService) {}

  ngOnInit(): void {

    this.getlatestUser();
  }

  addUser(formdata: any) {
    console.log(formdata);
    this.service.createUsers(formdata).subscribe((result: any) => {
      console.log('user is added');
      this.alert=true
      this.getlatestUser();

    });
  }
  closeAlert(){
    this.alert=false
  }

  getlatestUser() {

    this.service.getallUsers().subscribe((result) => {
      this.alluser = result;

    });
  }

  useredit(user:any) {

    this.isedit=true
    // this.edituser = Object.assign({},user)
    this.edituser = user
  }

  deleteuser(user: any) {
    if(confirm("are you sure to delete record ?"))
    this.service.deleteUsers(user).subscribe(() => {
      this.getlatestUser();
    });
  }

  updateuser(){

    this.isedit=!this.isedit;
    this.service.upadteUser(this.edituser).subscribe(()=>{
      this.getlatestUser()
    })
  }


}

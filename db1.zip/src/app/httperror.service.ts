import { Observable, throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class HttperrorService {
  url = 'http://localhost:3000/userfcfd';

  constructor(private http: HttpClient) {}

  getdata(){
    return this.http.get(this.url).pipe(catchError(this.HandleError));
  }

  HandleError(error: any) {
    return throwError(error.message || 'Server Error');
  }
}

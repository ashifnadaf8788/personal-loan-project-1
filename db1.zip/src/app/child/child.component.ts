import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
})
export class ChildComponent implements OnInit {
  @Input() hero: any;

  @Output() parent = new EventEmitter();
  constructor() {}

  ngOnInit(): void {
    console.log(this.hero);

  }

  senddata(){
    let data =[{ name: 'ashif', age: 23, address: 'shirati' }]
    this.parent.emit(data);
  }
}

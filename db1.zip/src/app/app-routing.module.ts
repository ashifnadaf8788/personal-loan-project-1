import { FilterComponent } from './filter/filter.component';
import { PipeComponent } from './pipe/pipe.component';
import { HttpErrorHandlingComponent } from './http-error-handling/http-error-handling.component';
import { HttpmethodComponent } from './httpmethod/httpmethod.component';
import { HttpPostMethodComponent } from './http-post-method/http-post-method.component';
import { HttpComponent } from './http/http.component';
import { StylingComponentComponent } from './styling-component/styling-component.component';
import { NgforComponent } from './ngfor/ngfor.component';
import { NgifNgforNgswitchComponent } from './ngif-ngfor-ngswitch/ngif-ngfor-ngswitch.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"Child",component:ChildComponent},
  {path:"Parent",component:ParentComponent},
  {path:"Data_Binding",component:DataBindingComponent},
  {path:"ngFor",component:NgforComponent},
  {path:"If_Switch",component:NgifNgforNgswitchComponent},
  {path:"styling_component",component:StylingComponentComponent},
  {path:"HTTP",component:HttpComponent},
  {path:"HTTP_post",component:HttpPostMethodComponent},
  {path:"HTTP_method",component:HttpmethodComponent},
  {path:"HTTP_error_handling",component:HttpErrorHandlingComponent},
  {path:"pipes",component:PipeComponent},
  {path:"filter",component:FilterComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

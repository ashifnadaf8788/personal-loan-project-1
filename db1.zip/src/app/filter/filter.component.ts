import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
namesearch:string =" ";
  productarr=[
    {
      srno:1,
      name:"mobile",
      price:"12000",
      availablity:"available"
    },
    {
      srno:2,
      name:"TV",
      price:"200000",
      availablity:"not available"
    },
    {
      srno:3,
      name:"laptop",
      price:"30000",
      availablity:"available"
    },
    {
      srno:4,
      name:"washing machine",
      price:"12000",
      availablity:" not available"
    },
    {
      srno:5,
      name:"mobile(samsung)",
      price:"12000",
      availablity:"available"
    },
    {
      srno:6,
      name:"tv(sansui)",
      price:"12000",
      availablity:"available"
    },
    {
      srno:7,
      name:"laptop(HP)",
      price:"12000",
      availablity:"not available"
    },
    {
      srno:8,
      name:"mobile(nokia)",
      price:"1200",
      availablity:"not available"
    },
  ]
  constructor() { }

  ngOnInit(): void {
  }

}

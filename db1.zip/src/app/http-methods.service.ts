import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpMethodsService {
  url="http://localhost:3000/user";

  constructor(private http :HttpClient) { }


  createUsers(user:any){
   return this.http.post(this.url,user)
  };

  getallUsers(){
    return this.http.get(this.url)
  }

  deleteUsers(user:any)
  {
    return this.http.delete( this.url +'/'+ user.id)
  }

  upadteUser(user:any){
    return this.http.put(this.url + '/' +user.id,user)
  }
}

import { MyserviceService } from './../myservice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-http-post-method',
  templateUrl: './http-post-method.component.html',
  styleUrls: ['./http-post-method.component.css']
})
export class HttpPostMethodComponent implements OnInit {
  name=""
  constructor(private service :MyserviceService) { }

  ngOnInit(): void {
  }
  getuserdata(data:any){
    console.warn(data);
    this.service.saveusers(data).subscribe((result)=>
    {
      console.log(result)
    })
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpPostMethodComponent } from './http-post-method.component';

describe('HttpPostMethodComponent', () => {
  let component: HttpPostMethodComponent;
  let fixture: ComponentFixture<HttpPostMethodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HttpPostMethodComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HttpPostMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

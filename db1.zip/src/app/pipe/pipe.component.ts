import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {
name="ashif nadaf living in shirati";
date =new Date();
a=10;
pi: number = 3.14159265359;
object= {foo: 'bar', baz: 'qux', nested: {xyz: 3, numbers: [1, 2, 3, 4, 5]}};
percent=2.8239742
doller=79.85;

arrname =[
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."},
  {username:"Lorem ipsum dolor sit amet."}

]
  constructor() { }

  ngOnInit(): void {
  }


}

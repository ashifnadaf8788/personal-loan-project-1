import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
data=[{
  name:"ashif nadaf",
  age:23,
  email:"ashifnadaf99@gmail.com"
}];
name=""
ParentComponent (data1:any){
  console.log(data1)
this.name=data1.name
}


  constructor() { }

  ngOnInit(): void {

  }

}

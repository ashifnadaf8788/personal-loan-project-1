import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StylingComponentComponent } from './styling-component.component';

describe('StylingComponentComponent', () => {
  let component: StylingComponentComponent;
  let fixture: ComponentFixture<StylingComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StylingComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StylingComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

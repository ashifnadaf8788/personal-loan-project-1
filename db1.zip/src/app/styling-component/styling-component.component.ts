import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-styling-component',
  templateUrl: './styling-component.component.html',
  styleUrls: ['./styling-component.component.css']
})
export class StylingComponentComponent implements OnInit {

  myclass={
    myclass1:true,
    myclass2:true,
    myclass3:true,
  }

  mystyle ={
    'background':'red',
    'border':'10px solid green'
  }

  constructor() { }

  ngOnInit(): void {
  }

}

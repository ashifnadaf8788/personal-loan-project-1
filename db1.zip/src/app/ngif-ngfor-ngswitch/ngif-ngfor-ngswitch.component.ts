import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngif-ngfor-ngswitch',
  templateUrl: './ngif-ngfor-ngswitch.component.html',
  styleUrls: ['./ngif-ngfor-ngswitch.component.css']
})
export class NgifNgforNgswitchComponent implements OnInit {
  show=true;
  hidden=false;
  day=1;
 

  constructor() { }

  ngOnInit(): void {
  }

  showdata(){
    this.show=!this.show
  }

  hide(){
    this.hidden =!this.hidden
  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngfor',
  templateUrl: './ngfor.component.html',
  styleUrls: ['./ngfor.component.css']
})
export class NgforComponent implements OnInit {


  product =[
    {proimg:"https://www.91-img.com/gallery_images_uploads/6/7/673822b9f164080c70731c30a8ba4f4ceb357cce.JPG?tr=h-550,w-0,c-at_max" , name:"mobile" , id:"1", price:200000},
    {proimg:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYNWN5k_yJVQULY7w8jW0Ctw8_1X4MNW4Kdg&usqp=CAU" , name:"laptop" , id:"2", price:18000},
    {proimg:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqbCCrGQb_fdQOXMcYZeEaFsakmG2_WehbgA&usqp=CAU" , name:"computer" , id:"3", price:22000},
    {proimg:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_asdSb723NZoEGcqSWR2Ra0fqfbJxIW0_XQ&usqp=CAU" , name:"projector" , id:"4", price:190000},
  ];

  users=[
    {userimg:"https://image.shutterstock.com/image-photo/young-handsome-man-beard-wearing-260nw-1768126784.jpg",userId:"1",name:"ashif nadaf",email:"ashifnadaf@gmail.com"},
    {userimg:"https://image.shutterstock.com/image-photo/young-handsome-man-beard-wearing-260nw-1768126784.jpg",userId:"2",name:"niranjan khochare",email:"niranjankhochare@gmail.com"},
    {userimg:"https://image.shutterstock.com/image-photo/young-handsome-man-beard-wearing-260nw-1768126784.jpg",userId:"3",name:"rushi kadam",email:"rushikadam@gmail.com"},
    {userimg:"https://image.shutterstock.com/image-photo/young-handsome-man-beard-wearing-260nw-1768126784.jpg",userId:"4",name:"akash",email:"akash@gmail.com"},
    {userimg:"https://image.shutterstock.com/image-photo/young-handsome-man-beard-wearing-260nw-1768126784.jpg",userId:"5",name:"jeevan",email:"jeevan@gmail.com"},
  ]
  constructor() { }

  ngOnInit(): void {
  }

}

import { HttperrorService } from './../httperror.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-http-error-handling',
  templateUrl: './http-error-handling.component.html',
  styleUrls: ['./http-error-handling.component.css'],
})
export class HttpErrorHandlingComponent implements OnInit {

  error:any;
  data:any;

  constructor(private service: HttperrorService) {}

  ngOnInit(): void {}

  getdata() {
    this.service.getdata().subscribe(
      (data: any) => {
        console.log(data);
        this.data=data
      },
      (error: any) => {
        console.log(error);
        this.error=error
      }
    );
  }
}

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
url="http://localhost:3000/user"
  constructor(private http : HttpClient) { }

  user(){
    return this.http.get("https://jsonplaceholder.typicode.com/users")
  }

  users(){

    let httpHeaders = new HttpHeaders({

      "Content-type": "application/json",
      "Authorization": "ashifnadaf32362873",
      "timeOutSecond":"3000"
    });

    httpHeaders = httpHeaders.set("ashif-developer-id","134");

    let time =httpHeaders.get("timeOutSecond")

    if (time==="3000") {
      httpHeaders=httpHeaders.set("Authorization","")

    }


    return this.http.get(this.url,{headers:httpHeaders})
  }
  saveusers(data:any){
    return this.http.post(this.url,data)
  }
}

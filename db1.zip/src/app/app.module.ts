import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { ParentComponent } from './parent/parent.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { NgifNgforNgswitchComponent } from './ngif-ngfor-ngswitch/ngif-ngfor-ngswitch.component';
import { NgforComponent } from './ngfor/ngfor.component';
import { StylingComponentComponent } from './styling-component/styling-component.component';
import { UserComponent } from './parameter/user/user.component';
import { UserDetailsComponent } from './parameter/user-details/user-details.component';
import { HttpComponent } from './http/http.component';
import { HttpPostMethodComponent } from './http-post-method/http-post-method.component';
import { HttpmethodComponent } from './httpmethod/httpmethod.component';
import { HttpErrorHandlingComponent } from './http-error-handling/http-error-handling.component';
import { PipeComponent } from './pipe/pipe.component';
import { CustompipePipe } from './custompipe.pipe';
import { FilterComponent } from './filter/filter.component';
import { FilterPipe } from './filter.pipe';



@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    ParentComponent,
    HeaderComponent,
    HomeComponent,
    DataBindingComponent,
    NgifNgforNgswitchComponent,
    NgforComponent,
    StylingComponentComponent,
    UserComponent,
    UserDetailsComponent,
    HttpComponent,
    HttpPostMethodComponent,
    HttpmethodComponent,
    HttpErrorHandlingComponent,
    PipeComponent,
    CustompipePipe,
    FilterComponent,
    FilterPipe,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

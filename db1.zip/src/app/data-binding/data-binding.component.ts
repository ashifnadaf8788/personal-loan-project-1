import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {
name="Ashif Nadaf ";
address="Shirati";
msg=""
value=""
uname="";
  constructor() { }

  ngOnInit(): void {
  }

  mydata(){
    this.msg="you click me";
    return console.log("yes")
  }
  inputclick(event:any){
    console.log(event.target.value);
  }

  show(event:any){
this.value=event.target.value
  }
}

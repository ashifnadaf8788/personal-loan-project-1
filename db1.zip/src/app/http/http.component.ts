import { HttpClient } from '@angular/common/http';
import { MyserviceService } from './../myservice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-http',
  templateUrl: './http.component.html',
  styleUrls: ['./http.component.css'],
})
export class HttpComponent implements OnInit {
  data: any;
  userdata: any = [];
  users: any;
  constructor(private service: MyserviceService) {
    // let mydata=this.data = this.service.user()

    // mydata.subscribe(data=>{
    //   for(const d of(data as any)){
    //     this.userdata.push(d)
    //   }
    //   console.log(this.userdata)
    // })
    this.service.users().subscribe((data) => {
      this.users = data;
    });
  }

  getdate(){
    
  }
  ngOnInit(): void {}
}
